import React from "react";
import { Container, Divider, Header, Message } from "semantic-ui-react";

import FormBuilder from './formBuilder';
const requireFields = [
    {
        type: 'checkbox',
        label: 'T&C',
        name: 'T&C'
    },
    {
        type: 'text',
        label: 'FirstName',
        name: 'firstName',
        placeholder: 'first name',
        validation: {
            errorType: 'required',
            // errorMessage: 'please enter above field'
        }
    },
    {
        type: 'text',
        label: 'LastName',
        name: 'lastName',
        placeholder: 'last name'
    },
    {
        type: 'text',
        label: 'Email',
        name: 'email',
        placeholder: 'email',
        validation: {
            errorType: 'email'
        }
    },
    {
        type: 'text',
        label: 'Age',
        name: 'age',
        placeholder: 'age',
        validation: {
            errorType: 'number',
            // errorMessage: 'please enter above field'
        }
    },
    {
        type: 'textField',
        label: 'address',
        name: 'address',
        placeholder: 'placeholder'
    },
    {
        type: 'radio',
        label: 'One',
        name: 'quantity',
        radioValue: 1
    },
    {
        type: 'radio',
        label: 'Two',
        name: 'quantity',
        radioValue: 2
    },
    {
        type: 'select',
        label: 'Gender',
        name: 'gender',
        placeholder: 'gender',
        options: [{ key: "m", text: "Male", value: "male" },
                { key: "f", text: "Female", value: "female" }]
    }
];

const handleFormSubmit = (formValues) => {
    console.log("formvalues", formValues);
};

const App = props => {
    return (
        <Container>
            <Divider hidden />

            <Header as="h1" dividing>
                A sample form with Semantic UI React and Redux Form
            </Header>

            <FormBuilder
                onSubmit={handleFormSubmit}
                datas={requireFields}
            />
            <Message>
                <Message.Header>Form data:</Message.Header>
                <pre>{JSON.stringify(props, null, 2)}</pre>
            </Message>
        </Container>
    )
};

export default App;