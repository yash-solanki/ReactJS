##Steps of running this project

from the command prompt clone the project

* $git clone https://github.com/techsithgit/combining-multiple-reducers.git
* $cd combining-multiple-reducers
* $npm install
* $npm start

[Watch the Tutorial]().
